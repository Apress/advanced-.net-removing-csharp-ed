Create a "virtual root" in IIS Admin called "MyAuthServer" pointing to this directory's vroot subdirectory to test the example.

When recompiling, you have to place the server.dll in vroot\bin!


