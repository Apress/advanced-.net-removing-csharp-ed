using System;
using System.Runtime.Remoting.Messaging;

namespace General
{
	public abstract class BaseRemoteObject: MarshalByRefObject
	{
		public abstract void setValue(int newval);
		public abstract int getValue();
		public abstract String getName();
	}
}
