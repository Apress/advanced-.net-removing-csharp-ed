using System;
using System.Runtime.Remoting;
using General;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting.Channels;
using System.Collections;

namespace Server
{

	class MyWorkerObject: BaseWorkerObject
	{

		public MyWorkerObject() 
		{
			Console.WriteLine("MyWorkerObject.Constructor: New Object created");
		}

		public override void doSomething(BaseRemoteObject usethis) 
		{
			Console.WriteLine("MyWorkerObject.doSomething(): called");
			Console.WriteLine("MyWorkerObject.doSomething(): Will now call" +
							  "getValue() on the remote obj.");

			int tmp = usethis.getValue();
			Console.WriteLine("MyWorkerObject.doSomething(): current value of " + 
								"the remote obj.; {0}", tmp);

			Console.WriteLine("MyWorkerObject.doSomething(): changing value to 70");
			usethis.setValue(70);
		}
	}

	class ServerStartup
	{
		static void Main(string[] args)
		{
			Console.WriteLine ("ServerStartup.Main(): Server [2] started");

			HttpChannel chnl = new HttpChannel(1235);
			ChannelServices.RegisterChannel(chnl);
			
			RemotingConfiguration.RegisterWellKnownServiceType(
					typeof(MyWorkerObject),
					"MyWorkerObject.soap", 
					WellKnownObjectMode.SingleCall);

			// the server will keep running until keypress.
			Console.ReadLine();
		}
	}
}
