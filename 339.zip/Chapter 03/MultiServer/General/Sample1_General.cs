using System;

namespace General
{
	public abstract class BaseRemoteObject: MarshalByRefObject
	{
		public abstract void setValue(int newval);
		public abstract int getValue();
	}

	public abstract class BaseWorkerObject: MarshalByRefObject
	{
		public abstract void doSomething(BaseRemoteObject usethis);
	}
}
