using System;

namespace General
{
	public interface IMyRemoteObject
	{
		void setValue(int newval);
		int getValue();
	}
}
