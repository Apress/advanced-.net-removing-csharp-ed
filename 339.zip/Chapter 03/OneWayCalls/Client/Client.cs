using System;
using System.Runtime.Remoting;
using General;
using System.Runtime.Remoting.Channels.Http;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Proxies;
using System.Threading;

namespace Client
{

	class Client
	{
		delegate void SetValueDelegate(int value);

		static void Main(string[] args)
		{
			HttpChannel channel = new HttpChannel();
			ChannelServices.RegisterChannel(channel);
			BaseRemoteObject obj = (BaseRemoteObject) Activator.GetObject(
				typeof(BaseRemoteObject),
				"http://localhost:1234/MyRemoteObject.soap");
			Console.WriteLine("Client.Main(): Reference to rem.obj. acquired");

			Console.WriteLine("Client.Main(): Will call setValue(42)");
			SetValueDelegate svDelegate = new SetValueDelegate(obj.setValue);
			IAsyncResult svAsyncres = svDelegate.BeginInvoke(42,null,null);
			Console.WriteLine("Client.Main(): Invocation done");

			Console.WriteLine("Client.Main(): EndInvoke for setValue()");
			try 
			{
				svDelegate.EndInvoke(svAsyncres);
				Console.WriteLine("Client.Main(): EndInvoke returned successfully");
			} 
			catch (Exception e) 
			{
				Console.WriteLine("Client.Main(): EXCEPTION during EndInvoke");
			}
			// wait for keypress
			Console.ReadLine();
		}	
	}
}
