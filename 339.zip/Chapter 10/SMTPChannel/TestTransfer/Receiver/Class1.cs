using System;
using SoftArtisans;

namespace Receiver
{
	class ReceiverTest
	{
		[STAThread]
		static void Main(string[] args)
		{
			SoftArtisans.SAPOP3 pop = new SAPOP3();
			pop.Host = "localhost";
			pop.UserName = "server_1";
			pop.Password = "server_1";
			pop.Start();
			Console.WriteLine("MsgCount: {0}", pop.MessageCount);
			for (int i =1;i<=pop.MessageCount;i++) {
				SAPOP3Message msg =  pop[i];
				Console.WriteLine("[{0}]: {1}", msg.Sender, msg.Subject);

				String tmp = msg.HeaderString;

				int pos = tmp.IndexOf("\nX-REMOTING-");
				while (pos >= 0) {
					int pos2 = tmp.IndexOf("\n",pos+1);
					String oneline = tmp.Substring(pos+1,pos2-pos-2);

					int poscolon = oneline.IndexOf(":");
					String key = oneline.Substring(11,poscolon-11).Trim();
					String headervalue = oneline.Substring(poscolon+1).Trim();
					Console.WriteLine(oneline);
					pos = tmp.IndexOf("\nX-REMOTING-",pos2);
				}

			}
			Console.WriteLine("Press <Return> to exit");

			Console.ReadLine();
		}
	}
}
