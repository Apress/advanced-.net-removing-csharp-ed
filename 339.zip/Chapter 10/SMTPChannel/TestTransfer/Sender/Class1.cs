using System;
using System.Web.Mail;

namespace Sender
{
	class MailSender
	{
		[STAThread]
		static void Main(string[] args)
		{
			MailMessage msg = new MailMessage();
			msg.From = "client_1@localhost";
			msg.To = "server_1@localhost";
			msg.Subject = "REQUEST: 4711";
			msg.Body = "Hello World!\n\nThis is a test ...";
			SmtpMail.SmtpServer = "localhost";
			SmtpMail.Send(msg);
		}
	}
}
