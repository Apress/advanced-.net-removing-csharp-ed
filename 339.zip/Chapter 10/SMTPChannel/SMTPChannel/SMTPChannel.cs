using System;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;

namespace SMTPChannel
{
	public class SMTPChannel: BaseChannelWithProperties, 
		IChannelSender, IChannelReceiver
	{
		SMTPClientChannel _clientchannel;
		SMTPServerChannel _serverchannel;
		String _name;

		public SMTPChannel (IDictionary properties, IClientChannelSinkProvider clientSinkProvider, IServerChannelSinkProvider serverSinkProvider) 
		{
			if (clientSinkProvider == null) 
			{
				clientSinkProvider = new SoapClientFormatterSinkProvider();
			}
			_clientchannel = new SMTPClientChannel(properties, clientSinkProvider);

			if ((properties["isServer"] != null) && 
				((String) properties["isServer"] == "yes" ))
			{
				if (serverSinkProvider == null) 
				{
					serverSinkProvider = new SoapServerFormatterSinkProvider();
				}
				_serverchannel = new SMTPServerChannel(properties, serverSinkProvider);
			}

			_name = (String) properties["name"];
		}

		public IMessageSink CreateMessageSink(string url, 
			object remoteChannelData, out string objectURI)
		{
			return _clientchannel.CreateMessageSink(url,
				remoteChannelData, out objectURI);
		}

		public string Parse(string url, out string objectURI)
		{
			return _clientchannel.Parse(url, out objectURI);
		}

		public string ChannelName
		{
			get
			{
				return _name;
			}
		}

		public int ChannelPriority
		{
			get
			{
				return 0;
			}

		}

		public void StartListening(object data)
		{
			if (_serverchannel != null) 
			{
				_serverchannel.StartListening(data);
			}
		}

		public void StopListening(object data)
		{
			if (_serverchannel != null) 
			{
				_serverchannel.StopListening(data);
			}
		}

		public string[] GetUrlsForUri(string objectURI)
		{
			if (_serverchannel != null) 
			{
				return _serverchannel.GetUrlsForUri(objectURI);
			} 
			else 
			{
				return null;
			}
		}

		public object ChannelData
		{
			get
			{
				if (_serverchannel != null ) 
				{
					return _serverchannel.ChannelData;
				} 
				else 
				{
					return null;
				}
			}
		}

	}
}
