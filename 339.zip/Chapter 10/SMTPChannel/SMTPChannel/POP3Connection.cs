using System;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Collections;
using System.Text;

namespace SMTPChannel 
{
	public class POP3Connection 
	{
		private class MessageIndex 
		{
			// will be used to store the result of the LIST command
			internal int Number;
			internal int Bytes;

			internal MessageIndex(int num, int msgbytes) 
			{
				Number = num;
				Bytes  = msgbytes;
			}
		}

		private String _hostname;
		private String _username;
		private String _password;
		private TcpClient _pop3Connection;
		private NetworkStream _pop3Stream;
		private StreamReader _pop3Response;
		private IDictionary _msgs;

		public int MessageCount 
		{
			get 
			{
				// returns the message count after connecting and
				// issuing the LIST command
				return _msgs.Count;
			}
		}

		public POP3Msg GetMessage(int msgnum) 
		{
			// create the resulting object
			POP3Msg tmpmsg = new POP3Msg();

			// retrieve a single message
			SendCommand("RETR " + msgnum,true);
			String response = _pop3Response.ReadLine();

			// read the response line by line and populate the
			// correct properties of the POP3Msg object

			StringBuilder headers = new StringBuilder();
			StringBuilder body = new StringBuilder();
			bool headersDone=false;
			while ((response!= null) && (response != "." )) 
			{
				// check if all headers have been read
				if (!headersDone) 
				{
					if (response.Length >0) 
					{
						// this will only parse the headers which are relevant
						// for .NET Remoting

						if (response.ToUpper().StartsWith("IN-REPLY-TO:")) 
						{
							tmpmsg.InReplyTo = response.Substring(12).Trim();
						}
						else if (response.ToUpper().StartsWith("MESSAGE-ID:")) 
						{
							tmpmsg.MessageId = response.Substring(11).Trim();
						}
						else if (response.ToUpper().StartsWith("FROM:")) 
						{
							tmpmsg.From = response.Substring(5).Trim();
						} 
						else if (response.ToUpper().StartsWith("TO:")) 
						{
							tmpmsg.To = response.Substring(3).Trim();
						}
						headers.Append(response).Append("\n");
					} 
					else 
					{
						headersDone = true;
					}
				} 
				else 
				{
					// all headers have been read, add the rest to
					// the body. 
					
					// For .NET Remoting, we need the body in a single 
					// line to decode Base64 therefore no <CR><LF>s will
					// be appended!
					body.Append(response);				
				}

				// read next line
				response = _pop3Response.ReadLine();
			}

			// set the complete header and body Strings of POP3Msg
			tmpmsg.Body = body.ToString();
			tmpmsg.Headers = headers.ToString();
			return tmpmsg;
		}

		public void DeleteMessage(int msgnum) 
		{
			// issue the DELE command to delete the specified message
			SendCommand("DELE " + msgnum,true);
		}

		public POP3Connection(String hostname, String username, String password) 
		{
			// try to connect to the server with the supplied username
			// and password.

			_hostname = hostname;
			_username = username;
			_password = password;
			try 
			{
				Connect();
			} 
			catch (Exception e) 
			{
				try 
				{ 
					Disconnect(); 
				} 
				catch (Exception ex) {/* ignore */}

				throw e;
			}
		}

		private void Connect() 
		{
			// initialize the list of messages
			_msgs = new Hashtable();

			// open the connection
			_pop3Connection = new TcpClient(_hostname,110);
			_pop3Stream = _pop3Connection.GetStream();
			_pop3Response = new StreamReader(_pop3Stream);
			
			// ignore first line (server's greeting)
			String response = _pop3Response.ReadLine();

			// authenticate
			SendCommand("USER " + _username,true);
			SendCommand("PASS " + _password,true);

			// retrieve the list of messages
			SendCommand("LIST",true);
			response = _pop3Response.ReadLine();
			while (response != ".") 
			{
				// add entries to _msgs dictionary
				int pos = response.IndexOf(" ");
				String msgnumStr = response.Substring(0,pos);
				String bytesStr = response.Substring(pos);
				
				int msgnum = Convert.ToInt32(msgnumStr);
				int bytes = Convert.ToInt32(bytesStr);

				MessageIndex msgidx = new MessageIndex(msgnum,bytes);
				_msgs.Add (msgidx,msgnum);
				response = _pop3Response.ReadLine();

			}
		}

		public void Disconnect() 
		{
			// sends QUIT and disconnects

			try 
			{
				// send QUIT to commit the DELEs
				SendCommand("QUIT",false);
			} 
			finally 
			{
				// close the connection
				_pop3Stream.Close();
				_pop3Response.Close();
				_pop3Connection.Close();
			}
		}

		private void SendCommand(String command,bool needOK) 
		{
			// sends a single command. 
			
			// if needOK is set it will check the response to begin
			// with "+OK" and will throw an exception if it doesn't.
			
			command = command + "\r\n";
			byte[] cmd = Encoding.ASCII.GetBytes(command);
			
			// send the command
			_pop3Stream.Write(cmd,0,cmd.Length);
			String response = _pop3Response.ReadLine();

			// check the response
			if (needOK) 
			{
				if (!response.Substring(0,3).ToUpper().Equals("+OK")) 
				{
					throw new Exception("POP3 Server returned unexpected " +
						"response:\n'" + response + "'");
				}
			}
		}
	}
}
