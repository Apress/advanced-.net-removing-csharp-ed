using System;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;

namespace SMTPChannel
{

	public class SMTPServerChannel: BaseChannelWithProperties, 
		IChannelReceiver, 
		IChannel
	{
		private String _myAddress;
		private String _name;
		private String _smtpServer;
		private String _pop3Server;
		private String _pop3Username;
		private String _pop3Password;
		private int _pop3Pollingtime;

		private SMTPServerTransportSink _transportSink;
		private IServerChannelSinkProvider _sinkProvider;
		private IDictionary _properties;

		private ChannelDataStore _channelData;

		public SMTPServerChannel(IDictionary properties, IServerChannelSinkProvider serverSinkProvider)
		{
			_sinkProvider = serverSinkProvider;
			_properties = properties;
			_myAddress = (String) _properties["senderEmail"];
			_name = (String) _properties["name"];
			_pop3Server = (String) _properties["pop3Server"];
			_smtpServer = (String) _properties["smtpServer"];
			_pop3Username = (String) _properties["pop3User"];
			_pop3Password = (String) _properties["pop3Password"];
			_pop3Pollingtime = 
				Convert.ToInt32((String) _properties["pop3PollInterval"]);

			String[] urls = { this.GetURLBase() };

			// needed for CAOs!
			_channelData = new ChannelDataStore(urls);
			
			// collect channel data from all providers
			IServerChannelSinkProvider provider = _sinkProvider;
			while (provider != null) 
			{
				provider.GetChannelData(_channelData);
				provider = provider.Next;
			}			

			// create the sink chain
			IServerChannelSink snk = 
				ChannelServices.CreateServerChannelSinkChain(_sinkProvider,this);

			// add the SMTPServerTransportSink as a first element to the chain
			_transportSink = new SMTPServerTransportSink(snk, _smtpServer,
				_myAddress);

			// start to listen
			this.StartListening(null);
		}

		private String GetURLBase() 
		{
			return "smtp:" + _myAddress;
		}

		public string Parse(string url, out string objectURI) 
		{
			String email;
			SMTPHelper.parseURL(url, out email, out objectURI);
			if (email == null || email=="" || objectURI == null || objectURI =="") 
			{
				return null;
			} 
			else 
			{
				return "smtp:" + email;
			}
		}

		public string ChannelName 
		{
			get 
			{
				return _name;
			}
		}

		public int ChannelPriority 
		{
			get 
			{
				return 0;
			}
		}


		public void StartListening(object data) 
		{
			// register the POP3 account for polling
			POP3PollManager.RegisterPolling(_pop3Server,_pop3Username,
				_pop3Password,_pop3Pollingtime,true);

			// register the email address as a server
			SMTPHelper.RegisterServer(_transportSink,_myAddress);
		}

		public void StopListening(object data) 
		{
			// Not implemented
		}

		public string[] GetUrlsForUri(string objectURI) 
		{
			String[] urls;
			urls = new String[1];
			if (!(objectURI.StartsWith("/")))
				objectURI = "/" + objectURI;
			urls[0] = this.GetURLBase() + objectURI;
			return urls;
		}

		public object ChannelData 
		{
			get 
			{
				return _channelData;
			}
		}
	}
}
