using System;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace SMTPChannel
{
	internal class AsyncResponseHandler
	{
		IClientChannelSinkStack _sinkStack;

		internal AsyncResponseHandler(IClientChannelSinkStack sinkStack)
		{
			_sinkStack = sinkStack;
		}

		internal void HandleAsyncResponsePop3Msg(POP3Msg popmsg) 
		{
			ITransportHeaders responseHeaders;
			Stream responseStream;
			String ID;
			SMTPHelper.ProcessMessage(popmsg,out responseHeaders,out responseStream,out ID);
			_sinkStack.AsyncProcessResponse(responseHeaders,responseStream);
		}
	}
}
