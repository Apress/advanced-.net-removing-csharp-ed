using System;
using System.Collections;
using System.Threading;

namespace SMTPChannel
{
	public class POP3Polling
	{
		delegate void HandleMessageDelegate(POP3Msg msg);
		
		// if it's a remoting server, we will poll forever
		internal bool _isServer; 

		// if this is not a server, this property has to be set to 
		// start polling
		internal bool _needsPolling;

		// is currently polling
		internal bool _isPolling;

		// polling interval in seconds
		internal int _pollInterval;

		// logon data
		private String _hostname;
		private String _username;
		private String _password;

		internal POP3Polling(String hostname, String username, String password, int pollInterval, bool isServer)
		{
			_hostname = hostname;
			_username = username;
			_password = password;
			_pollInterval = pollInterval;
			_isServer = isServer;

			if (!_isServer) { _needsPolling = false; }
		}


		private void Poll() 
		{
			if (_isPolling) return;
			_isPolling = true;
			do 
			{
				Thread.Sleep(_pollInterval * 1000);
				
				POP3Connection pop = new POP3Connection(_hostname,_username,_password);
				for (int i =1;i<=pop.MessageCount;i++) 
				{
					POP3Msg msg =  pop.GetMessage(i);
					HandleMessageDelegate del = new HandleMessageDelegate(SMTPHelper.MessageReceived);
					del.BeginInvoke(msg,null,null);
					pop.DeleteMessage(i);
				}
				pop.Disconnect();
				pop = null;
			} while (_isServer || _needsPolling);
			_isPolling = false;
		}

		internal void CheckAndStartPolling() 
		{
			if (_isPolling) return;

			if (_isServer || _needsPolling) 
			{
				Thread thr = new Thread(new ThreadStart(this.Poll));
				thr.Start();
				thr.IsBackground = true;
			}
		}


	}
}
