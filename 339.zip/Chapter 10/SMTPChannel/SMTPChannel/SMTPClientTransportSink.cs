using System;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.IO;

namespace SMTPChannel
{

	public class SMTPClientTransportSink: BaseChannelSinkWithProperties,
		IClientChannelSink, IChannelSinkBase
	{
		String _destinationEmailAddress;
		String _senderEmailAddress;
		String _objectURI;
		String _smtpServer;

		public SMTPClientTransportSink(String destinationEmailAddress, 
			String senderEmailAddress, String smtpServer, String objectURI)
		{	
			_destinationEmailAddress = destinationEmailAddress;
			_senderEmailAddress = senderEmailAddress;
			_objectURI = objectURI;
			_smtpServer = smtpServer;
			
		}

		public void ProcessMessage(IMessage msg, 
			ITransportHeaders requestHeaders, Stream requestStream, 
			out ITransportHeaders responseHeaders, 
			out Stream responseStream) 
		{
			String ID;
			String objectURI;
			String email;

			// check the URL
			String URL = (String) msg.Properties["__Uri"];
			SMTPHelper.parseURL(URL,out email,out objectURI);
			if ((email==null) || (email == "")) 
			{
				email = _destinationEmailAddress;
			}

			// send the message
			SMTPHelper.SendRequestMessage(_senderEmailAddress,email,_smtpServer,requestHeaders,requestStream,objectURI, out ID);

			// wait for the response
			POP3Msg popmsg = SMTPHelper.WaitAndGetResponseMessage(ID);

			// process the response
			SMTPHelper.ProcessMessage(popmsg,out responseHeaders,out responseStream,out ID);
		}


		public void AsyncProcessRequest(IClientChannelSinkStack sinkStack, 
			IMessage msg, ITransportHeaders headers, Stream stream) 
		{
			String ID;
			String objectURI;
			String email;

			// parse the url
			String URL = (String) msg.Properties["__Uri"];
			SMTPHelper.parseURL(URL,out email,out objectURI);
			if ((email==null) || (email == "")) 
			{
				email = _destinationEmailAddress;
			}

			// send the request message
			SMTPHelper.SendRequestMessage(_senderEmailAddress,email,_smtpServer,
				headers,stream,objectURI, out ID);

			// create and register an async response handler
			AsyncResponseHandler ar = new AsyncResponseHandler(sinkStack);
			SMTPHelper.RegisterAsyncResponseHandler(ID, ar);
		}

		public void AsyncProcessResponse(System.Runtime.Remoting.Channels.IClientResponseChannelSinkStack sinkStack, object state, System.Runtime.Remoting.Channels.ITransportHeaders headers, System.IO.Stream stream) 
		{
			// not needed in a transport sink!
			throw new NotSupportedException();
		}

		public Stream GetRequestStream(System.Runtime.Remoting.Messaging.IMessage msg, System.Runtime.Remoting.Channels.ITransportHeaders headers) 
		{
			// no direct way to access the stream
			return null;
		}

		public System.Runtime.Remoting.Channels.IClientChannelSink NextChannelSink 
		{
			get 
			{
				// no more sinks
				return null;
			}
		}
	
	}
}
