using System;
using System.Collections;
using System.Threading;

namespace SMTPChannel
{
	public class POP3PollManager
	{
		// dictionary of polling instances
		static IDictionary _listeners = Hashtable.Synchronized(new Hashtable());
		
		// number of sent messages for which no response has been received
		private static int _pendingResponses;
		private static int _lastPendingResponses;

		public static void RegisterPolling(String hostname, String username, 
			String password, int pollInterval, bool isServer) 
		{
			String key = username + "|" + hostname;
			POP3Polling pop3 = (POP3Polling) _listeners[key];
			if (pop3 == null) 
			{
				// create a new listener
				pop3 = new POP3Polling(hostname,username,password,
					pollInterval,isServer);

				_listeners[key]= pop3;
			} 
			else 
			{
				// change to server-mode if needed
				if (!pop3._isServer && isServer) 
				{
					pop3._isServer = true;
				}

				// check for pollInterval => lowest interval will be taken
				if (! (pop3._pollInterval > pollInterval)) 
				{
					pop3._pollInterval = pollInterval;
				}
			}
			pop3.CheckAndStartPolling();
		}

		internal static void RequestSent() 
		{
			_pendingResponses++;
			if (_lastPendingResponses<=0 && _pendingResponses > 0) 
			{
				IEnumerator enmr = _listeners.GetEnumerator();
				while (enmr.MoveNext()) 
				{
					DictionaryEntry entr = (DictionaryEntry) enmr.Current;
					POP3Polling pop3 = (POP3Polling) entr.Value;
					pop3._needsPolling = true;
					pop3.CheckAndStartPolling();
				}
			}
			_lastPendingResponses = _pendingResponses;
		}

		internal static void ResponseReceived() 
		{
			_pendingResponses--;
			if (_pendingResponses <=0) 
			{
				IEnumerator enmr = _listeners.GetEnumerator();
				while (enmr.MoveNext()) 
				{
					DictionaryEntry entr = (DictionaryEntry) enmr.Current;
					POP3Polling pop3 = (POP3Polling) entr.Value;
					pop3._needsPolling = false;
				}
			}
			_lastPendingResponses = _pendingResponses;
		}

	}
}
