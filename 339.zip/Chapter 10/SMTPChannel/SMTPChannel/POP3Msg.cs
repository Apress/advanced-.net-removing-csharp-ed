using System;
using System.Collections;

namespace SMTPChannel
{
	public class POP3Msg
	{
		public String From;
		public String To;
		public String Body;
		public String Headers;
		public String MessageId;
		public String InReplyTo;
	}
}
