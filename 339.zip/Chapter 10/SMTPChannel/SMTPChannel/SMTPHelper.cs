using System;
using System.Text;
using System.IO;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Threading;

namespace SMTPChannel 
{

	public class SMTPHelper 
	{

		// threads waiting for response
		private static IDictionary _waitingFor = 
			Hashtable.Synchronized(new Hashtable());

		// known servers
		private static IDictionary _servers = 
			Hashtable.Synchronized(new Hashtable());

		// responses received
		private static IDictionary _responses = 
			Hashtable.Synchronized(new Hashtable());


		// sending messages
		private static void SendMessage(String ID,String replyToId, 
			String mailfrom, String mailto, String smtpServer, 
			ITransportHeaders headers, 	Stream stream, String objectURI) 
		{
			StringBuilder msg = new StringBuilder();

			if (ID != null) 
			{
				msg.Append("Message-Id: ").Append(ID).Append("\r\n");
			}
			if (replyToId != null) 
			{
				msg.Append("In-Reply-To: ").Append(replyToId).Append("\r\n");
			}
			msg.Append("From: ").Append(mailfrom).Append("\r\n");
			msg.Append("To: ").Append(mailto).Append("\r\n");
			msg.Append("MIME-Version: 1.0").Append("\r\n");
			msg.Append("Content-Type: text/xml; charset=utf-8").Append("\r\n");
			msg.Append("Content-Transfer-Encoding: BASE64").Append("\r\n");

			// write the remoting headers			
			IEnumerator headerenum = headers.GetEnumerator();
			while (headerenum.MoveNext()) 
			{
				DictionaryEntry entry = (DictionaryEntry) headerenum.Current;
				String key = entry.Key as String;
				if (key == null || key.StartsWith("__")) 
				{
					continue;
				}
				msg.Append("X-REMOTING-").Append(key).Append(": ");
				msg.Append(entry.Value.ToString()).Append("\r\n");
			}

			if (objectURI != null) 
			{
				msg.Append("X-REMOTING-URI: ").Append(objectURI).Append("\r\n");
			}

			msg.Append("\r\n");
			MemoryStream fs = new MemoryStream();
			
			byte[] buf = new Byte[1000];
			int cnt = stream.Read(buf,0,1000);
			int bytecount = 0;
			while (cnt>0) 
			{
				fs.Write(buf,0,cnt);
				bytecount+=cnt;
				cnt = stream.Read(buf,0,1000);
			}


			// convert the whole string to Base64 encoding
			String body = Convert.ToBase64String(fs.GetBuffer(),0,bytecount);

			// and ensure the maximum line length of 73 characters
			int linesNeeded = (int) Math.Ceiling(body.Length / 73);
			
			for (int i = 0;i<=linesNeeded;i++) 
			{
				if (i != linesNeeded) 
				{
					String line = body.Substring(i*73,73);
					msg.Append(line).Append("\r\n");
				} 
				else 
				{
					String line = body.Substring(i*73);
					msg.Append(line).Append("\r\n");
				}
			}
			
			// send the resulting message
			SMTPConnection con = new SMTPConnection (smtpServer);
			con.SendMessage(mailfrom,mailto,msg.ToString());
		}

		internal static void SendRequestMessage(String mailfrom, String mailto, 
			String smtpServer, ITransportHeaders headers, Stream request, 
			String objectURI, out String ID) 
		{
			ID = "<" + Guid.NewGuid().ToString().Replace("-","") + "@REMOTING>";
			SendMessage(ID,null,mailfrom,mailto,smtpServer,headers,request,objectURI);
			POP3PollManager.RequestSent();
		}

		internal static void SendResponseMessage(String mailfrom, String mailto, 
			String smtpServer, ITransportHeaders headers, Stream response, 
			String ID) 
		{
			SendMessage(null,ID,mailfrom,mailto,smtpServer,headers,response,null);
		}	


		// waiting for responses
		internal static POP3Msg WaitAndGetResponseMessage(String ID) 
		{
			// suspend the thread until the message returns
			_waitingFor[ID] = Thread.CurrentThread;
			
			Thread.CurrentThread.Suspend();

			// waiting for resume
			POP3Msg pop3msg = (POP3Msg) _responses[ID];
			_responses.Remove(ID);
			return pop3msg;
		}

		internal static void RegisterAsyncResponseHandler(String ID, 
			AsyncResponseHandler ar) 
		{
			_waitingFor[ID] = ar;
		}

		// handling responses


		internal static void MessageReceived(POP3Msg pop3msg) 
		{
			// whenever a pop3 message has been received, it
			// will be forwarded to this method


			// check if it's a request or a reply
			if ((pop3msg.InReplyTo == null) && (pop3msg.MessageId != null)) 
			{
				// it's a request

				String requestID = pop3msg.MessageId;
				
				// Request received 

				// check for a registered server
				SMTPServerTransportSink snk = (SMTPServerTransportSink) 
					_servers[GetCleanAddress(pop3msg.To)];

				if (snk==null) 
				{
					// No server side sink found for address 
					return;
				}

				// Dispatch the message to serversink
				snk.HandleIncomingMessage(pop3msg);

			} 
			else if (pop3msg.InReplyTo != null) 
			{
				// a response must contain the in-reply-to header
				String responseID = pop3msg.InReplyTo.Trim();

				// check who's waiting for it
				Object notify = _waitingFor[responseID];

				if (notify as Thread != null) 
				{
					_responses[responseID] = pop3msg;

					// Waiting thread found. Will wake it up
					_waitingFor.Remove(responseID );
					((Thread) notify).Resume();
					POP3PollManager.ResponseReceived();
				} 
				else if (notify as AsyncResponseHandler != null) 
				{
					_waitingFor.Remove(responseID);
					POP3PollManager.ResponseReceived();
					((AsyncResponseHandler)notify).HandleAsyncResponsePop3Msg(
						pop3msg);
				} 
				else 
				{
					// No one is waiting for this reply. Ignore.
				}
			}
		}


		// helper to split the message
		internal static void ProcessMessage(POP3Msg pop3msg, 
			out ITransportHeaders headers, out Stream stream, out String ID) 
		{
			// this method will split it into a TransportHeaders and 
			// a Stream object and will return the "remoting ID"
			
			headers = new TransportHeaders();


			// first all remoting headers (which start with "X-REMOTING-")
			// will be extracted and stored in the TransportHeaders object
			String tmp = pop3msg.Headers;
			int pos = tmp.IndexOf("\nX-REMOTING-");
			while (pos >= 0) 
			{
				int pos2 = tmp.IndexOf("\n",pos+1);
				String oneline = tmp.Substring(pos+1,pos2-pos-1);

				int poscolon = oneline.IndexOf(":");
				String key = oneline.Substring(11,poscolon-11).Trim();
				String headervalue = oneline.Substring(poscolon+1).Trim();
				if (key.ToUpper() != "URI") 
				{
					headers[key] = headervalue;
				} 
				else 
				{
					headers["__RequestUri"] = headervalue;
				}
				pos = tmp.IndexOf("\nX-REMOTING-",pos2);
			}

			String fulltext = pop3msg.Body ;
			fulltext = fulltext.Trim();
			byte[] buffer = Convert.FromBase64String(fulltext);
			stream=new MemoryStream(buffer);

			ID = pop3msg.MessageId;
		}



		// helpers
		public static void RegisterServer(SMTPServerTransportSink snk, 
			String address) 
		{
			// Registering sink for a specified email address
			_servers[address] = snk;
		}

		internal static void parseURL(String url, out String email, 
			out String objectURI) 
		{
			// format:   "smtp:user@host.domain/URL/to/object"

			// is splitted to:
			//		email = user@host.domain
			//		objectURI = /URL/to/object
			int pos = url.IndexOf("/");
			if (pos > 0) 
			{
				email = url.Substring(5,pos-5);
				objectURI = url.Substring(pos);
			} 
			else if (pos ==-1) 
			{
				email = url.Substring(5);
				objectURI ="";
			} 
			else 
			{
				email = null;
				objectURI = url;
			}

		}	

		public static String GetCleanAddress(String address) 
		{
			// changes any kind of address like "someone@host" 
			// "<someone@host>" "<someone@host> someone@host"
			// to a generic format of "someone@host"

			address = address.Trim();
			int posAt = address.IndexOf("@");
			int posSpaceAfter = address.IndexOf(" ",posAt);
			if (posSpaceAfter != -1) address = address.Substring(0,posSpaceAfter);

			int posSpaceBefore = address.LastIndexOf(" ");

			if (posSpaceBefore != -1 && posSpaceBefore < posAt)  
			{
				address = address.Substring(posSpaceBefore+1);
			}

			int posLt = address.IndexOf("<");
			if (posLt != -1) 
			{
				address = address.Substring(posLt+1);
			}

			int posGt = address.IndexOf(">");
			if (posGt != -1) 
			{
				address = address.Substring(0,posGt);
			}

			return address;
		}
	}
}
