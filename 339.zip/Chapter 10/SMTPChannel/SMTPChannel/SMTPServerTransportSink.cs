using System;
using System.IO;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;

namespace SMTPChannel
{

	public class SMTPServerTransportSink: IServerChannelSink 
	{
		// will be used as a state object for the async reply
		private class SMTPState 
		{
			internal String ID;
			internal String responseAddress;
		}
		
		private String _smtpServer;
		private String _myAddress;
		private IServerChannelSink _nextSink;

		public SMTPServerTransportSink(IServerChannelSink nextSink, String smtpServer, String myAddress) 
		{
			_nextSink = nextSink;
			_smtpServer =smtpServer;
			_myAddress = myAddress;
		}

		public void HandleIncomingMessage(POP3Msg popmsg) 
		{
			Stream requestStream;
			ITransportHeaders requestHeaders;
			String ID;

			// split the message in Stream and ITransportHeaders
			SMTPHelper.ProcessMessage(popmsg,out requestHeaders, 
				out requestStream, out ID);

			//Console.WriteLine("-- URL: {0}",requestHeaders["__RequestUri"]);
			//Console.WriteLine("-- SoapAction: {0}",requestHeaders["SOAPAction"]);

			// create a new sink stack
			ServerChannelSinkStack stack = new ServerChannelSinkStack();

			// create a new state object and populate it 
			SMTPState state = new SMTPState();
			state.ID = ID;
			state.responseAddress = SMTPHelper.GetCleanAddress(popmsg.From );

			// push this sink onto the stack
			stack.Push(this,state);

			IMessage responseMsg;
			Stream responseStream;
			ITransportHeaders responseHeaders;

			// forward the call to the next sink
			ServerProcessing proc = _nextSink.ProcessMessage(stack,null,requestHeaders,requestStream,out responseMsg, out responseHeaders, out responseStream);
			
			// check the return value. 
			switch (proc) 
			{
				// this message has been handled synchronously
				case ServerProcessing.Complete:
					// send a response message
					SMTPHelper.SendResponseMessage(_myAddress,
						state.responseAddress,_smtpServer,responseHeaders,
						responseStream,state.ID);
					break;

				// this message has been handled asynchronously
				case ServerProcessing.Async:
					// nothing needs to be done yet 
					break;

				// it's been a one way message
				case ServerProcessing.OneWay:
					// nothing needs to be done yet 
					break;
			}
		}

		public void AsyncProcessResponse(
			IServerResponseChannelSinkStack sinkStack, object state, 
			IMessage msg, ITransportHeaders headers, System.IO.Stream stream) 
		{

			// fetch the state object
			SMTPState smtpstate = (SMTPState) state;

			// send the response email
			SMTPHelper.SendResponseMessage(_myAddress,
				smtpstate.responseAddress,_smtpServer,headers,
				stream,smtpstate.ID);
		}

		public IServerChannelSink NextChannelSink 
		{
			get 
			{
				return _nextSink;
			}
		}

		public System.Collections.IDictionary Properties 
		{
			get 
			{
				// not needed
				return null;
			}
		}

		public ServerProcessing ProcessMessage(
			IServerChannelSinkStack sinkStack, IMessage requestMsg, 
			ITransportHeaders requestHeaders, Stream requestStream, 
			out IMessage responseMsg, out ITransportHeaders responseHeaders, 
			out Stream responseStream) 
		{
			// will never be called for a server side transport sink
			throw new NotSupportedException();
		}

		public Stream GetResponseStream(
			IServerResponseChannelSinkStack sinkStack, object state, 
			IMessage msg, ITransportHeaders headers) 
		{
			// it's not possible to directly access the stream 
			return null;
		}


	}
}
