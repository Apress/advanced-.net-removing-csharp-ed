using System;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Text;

namespace SMTPChannel
{
	public class SMTPConnection
	{
		private String _hostname;
		private TcpClient _smtpConnection;
		private NetworkStream _smtpStream;
		private StreamReader _smtpResponse;

		public SMTPConnection(String hostname) {
			_hostname = hostname;
		}

		private void Connect() {
			_smtpConnection = new TcpClient(_hostname,25);
			_smtpStream = _smtpConnection.GetStream();
			_smtpResponse = new StreamReader(_smtpStream);
		}

		private void Disconnect() {
			_smtpStream.Close();
			_smtpResponse.Close();
			_smtpConnection.Close();
		}

		private void SendCommand(String command, int expectedResponseClass) {
			// command: the SMPT command to send
			// expectedResponseClass: first digit of the expected smtp response
			
			// Throws an exception if the server's responsecode's first 
			// digit (resonse class) is > the expectedResponseClass. 

			// If expectedResponseClass == 0, it will be ignored

			command = command + "\r\n";
			byte[] cmd = Encoding.ASCII.GetBytes(command);
			_smtpStream.Write(cmd,0,cmd.Length);
			String response = _smtpResponse.ReadLine();

			if (expectedResponseClass != 0) {
				int resp = Convert.ToInt32(response.Substring(0,1));
				if (resp > expectedResponseClass) {
					throw new Exception("SMTP Server returned unexpected " + 
						"response:\n'" + response + "'");
				}
			}
		}

		public void SendMessage(String from, String to, String text) {
			try 
			{
				Connect();
				SendCommand("HELO localhost",2);
				SendCommand("MAIL FROM: <" + from + ">",2);
				SendCommand("RCPT TO: <" + to + ">",2);
				SendCommand("DATA",3);
				byte[] bodybytes = Encoding.ASCII.GetBytes(text + "\r\n");
				_smtpStream.Write(bodybytes,0,bodybytes.Length);
				SendCommand(".",3);
				SendCommand("QUIT",0);
			} finally {
				try {
					Disconnect();
				} catch (Exception e) {/*ignore*/};
			}
		}
	
	}
}
