using System;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;

namespace SMTPChannel
{
	public class SMTPClientChannel: BaseChannelWithProperties, IChannelSender
	{
		IDictionary _properties;
		IClientChannelSinkProvider _provider;
		String _name;

		public SMTPClientChannel (IDictionary properties, IClientChannelSinkProvider clientSinkProvider) 
		{
			_properties = properties;
			_provider = clientSinkProvider;
			_name = (String) _properties["name"];

			POP3PollManager.RegisterPolling(
				(String) _properties["pop3Server"],
				(String) _properties["pop3User"],
				(String) _properties["pop3Password"],
				Convert.ToInt32((String)_properties["pop3PollInterval"]),
				false);
		}

		public string ChannelName 
		{
			get 
			{
				return _name;
			}
		}

		public int ChannelPriority 
		{
			get 
			{
				return 0;
			}
		}

		public string Parse(string url, out string objectURI) 
		{
			String email;
			SMTPHelper.parseURL(url, out email, out objectURI);
			if (email == null || email=="" || objectURI == null || objectURI =="") 
			{
				return null;
			} 
			else 
			{
				return "smtp:" + email;
			}
		}


		public IMessageSink CreateMessageSink(string url, object remoteChannelData, 
			out string objectURI) 
		{

			if (url == null && remoteChannelData != null && remoteChannelData as IChannelDataStore != null ) 
			{
				IChannelDataStore ds = (IChannelDataStore) remoteChannelData;
				url = ds.ChannelUris[0];
			}

			// format:   "smtp:user@host.domain/URI/to/object"
			if (url != null && url.ToLower().StartsWith("smtp:")) 
			{
				// walk to last provider and this channel sink's provider
				IClientChannelSinkProvider prov = _provider;
				while (prov.Next != null) { prov = prov.Next ;};
				prov.Next = new SMTPClientTransportSinkProvider((String) _properties["senderEmail"], (String) _properties["smtpServer"]);

				String dummy;
				SMTPHelper.parseURL(url,out dummy,out objectURI);
				IMessageSink msgsink = (IMessageSink) _provider.CreateSink(this,url,remoteChannelData);
				return msgsink;
			} 
			else 
			{
				objectURI =null;
				return null;
			}
		}

	}
}
