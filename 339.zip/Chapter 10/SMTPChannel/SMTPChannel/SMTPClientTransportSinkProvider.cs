using System;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;

namespace SMTPChannel
{
	public class SMTPClientTransportSinkProvider: IClientChannelSinkProvider
	{

		String _senderEmailAddress;
		String _smtpServer;

		public SMTPClientTransportSinkProvider(String senderEmailAddress, String smtpServer) 
		{	
			_senderEmailAddress = senderEmailAddress;
			_smtpServer = smtpServer;
		}

		public IClientChannelSink CreateSink(IChannelSender channel, 
			string url, object remoteChannelData) 
		{

			String destinationEmailAddress;
			String objectURI;
			SMTPHelper.parseURL(url,out destinationEmailAddress,out objectURI);
			return new SMTPClientTransportSink(destinationEmailAddress,_senderEmailAddress,_smtpServer, objectURI);
		}

		public IClientChannelSinkProvider Next 
		{
			get 
			{
				return null;
			}
			set 
			{
				// ignore as this has to be the last provider in the chain
			}
		}
	}
}
