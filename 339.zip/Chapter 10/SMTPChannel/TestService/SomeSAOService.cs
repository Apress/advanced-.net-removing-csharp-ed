using System;
using System.Threading;


namespace Service 
{

	public delegate void CallbackDelegate(String message);

	public class SomeSAO: MarshalByRefObject
	{
		public event CallbackDelegate OnCallback;
		
		public void raiseCallback(String message) 
		{
			// call the delegates manually to remove them if they aren't
			// active anymore.
			Console.WriteLine("Will raise events now");

			if (OnCallback == null) 
			{
				Console.WriteLine("No listeners");
			} 
			else 
			{
				Console.WriteLine("Number of Listeners: {0}",OnCallback.GetInvocationList().Length);
				CallbackDelegate mah=null;

				foreach (Delegate del in OnCallback.GetInvocationList()) 
				{
					try 
					{
						mah = (CallbackDelegate) del;
						mah(message);
					} 
					catch (Exception e) 
					{
						Console.WriteLine("Exception occured, will remove Delegate");
						OnCallback -= mah;
					}
				}
			}
		}
				
		public String doSomething(String x) 
		{
			Console.WriteLine("SomeSAO.doSomething called");
			return (x);
		}

		public String getCAOsName(SomeCAO mycao) {
			return mycao.Name;
		}
	}

	public class SomeCAO: MarshalByRefObject {
		private String _name;

		public String Name {
			get {
				Console.WriteLine("Returning CAOs name [{0}]", _name);
				return _name;
			}
			set {
				_name = value;
				Console.WriteLine("Setting name of CAO to: {0}",_name);
			}
		}
	}

	
	public class CallbackEventWrapper: MarshalByRefObject 
	{
		public event CallbackDelegate OnLocalCallback;

		// don't use OneWay here!
		public void LocallyHandleCallback (String msg) 
		{
			// forward the message to the client
			OnLocalCallback(msg);
		}

		public override object InitializeLifetimeService() 
		{
			// this object has to live "forever"
			return null;
		}
	}
	


	}