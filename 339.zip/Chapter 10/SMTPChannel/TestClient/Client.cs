using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using Service; // from service.dll

namespace Client
{

	class Client
	{

		delegate String DoSthDel(String x);
		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);
			
			SomeSAO server1_sao = new SomeSAO();
			Console.WriteLine("---- Testing sync calls ----");
			String res = server1_sao.doSomething("Testing");
			Console.WriteLine("Got sync result: {0}",res);


			Console.WriteLine("---- Testing async calls ----");

			DoSthDel dsd = new DoSthDel(server1_sao.doSomething);
			IAsyncResult ar= dsd.BeginInvoke("Testing async",null,null);
			res = dsd.EndInvoke(ar);
			Console.WriteLine("Got async result: {0}",res);


			Console.WriteLine("---- Testing CAOs on multiple servers ----");
			SomeCAO server2_cao = new SomeCAO();
			server2_cao.Name = "ThisIsMyTestCAO";
		

			String caoName = server1_sao.getCAOsName(server2_cao);
   		    Console.WriteLine("Server 1 returned CAO's name [{0}]",caoName);
			String realCaoName = server2_cao.Name;
			Console.WriteLine("Server 2 returned CAO's name [{0}]",realCaoName);

			Console.WriteLine("----- Testing events ----");

			Console.WriteLine("Registering callback");

			CallbackEventWrapper wrap = new CallbackEventWrapper();
			wrap.OnLocalCallback += new CallbackDelegate(HandleCallback);
			server1_sao.OnCallback += new CallbackDelegate(wrap.LocallyHandleCallback);
			Console.WriteLine("Telling server to call back");
			server1_sao.raiseCallback("Testing ...");
			Console.WriteLine("---- You should have received the callback by now ----");
			Console.ReadLine();
		}	

		public static void HandleCallback(String message) 
		{
			Console.WriteLine("Callback received: {0}",message);
			Console.WriteLine("---- All tests completed ----");
			Console.WriteLine("Press <return> to exit.");
		}
	}
}

