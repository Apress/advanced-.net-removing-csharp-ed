using System;
using System.Collections;
using System.Runtime.Remoting;
using Server;

namespace Client
{
	class Client
	{


		delegate void DoSomethingDelegate (SomeSAO sao);

		static void WrappedDoSomething(SomeSAO sao) {
			// this method will just forward the call to the SAO
			sao.DoSomething();
		}

		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			SomeSAO sao = new SomeSAO();
			
			DoSomethingDelegate del = new DoSomethingDelegate(WrappedDoSomething);
			try {
				Console.WriteLine("BeginInvoke will be called");
				IAsyncResult ar = del.BeginInvoke(sao, null,null);

				Console.WriteLine("EndInvoke will be called");
				del.EndInvoke(ar);

				Console.WriteLine("Invocation done");
			} catch (Exception e) {
				Console.WriteLine("EXCEPTION \n{0}",e.Message);
			}

			Console.ReadLine();
		}	
	}
}

