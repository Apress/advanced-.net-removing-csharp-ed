using System;
using System.Runtime.Remoting;
using System.Threading;
using General;

namespace Server
{

	public class SomeSAO: MarshalByRefObject, IMySAO
	{
		public void DoSomething() 
		{
			// simulating a long-running query
			Console.WriteLine("DoSomething() called");
			Thread.Sleep(5000);
			Console.WriteLine("DoSomething() done");
		}
	}

	class ServerStartup
	{
		static void Main(string[] args)
		{
			String filename = "server.exe.config";
			RemotingConfiguration.Configure(filename);

			Console.WriteLine ("Server started, press <return> to exit.");
			Console.ReadLine();
		}
	}
}
