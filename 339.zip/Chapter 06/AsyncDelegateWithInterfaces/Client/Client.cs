using System;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Activation;
using General;


namespace Client
{
	class Client
	{
		delegate void DoSomethingDelegate ();

		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			IMySAO sao = (IMySAO) RemotingHelper.GetObject(typeof(IMySAO));

			Console.WriteLine("Calling synchronously");
			sao.DoSomething();


			DoSomethingDelegate del = new DoSomethingDelegate(sao.DoSomething);
			
			Console.WriteLine("BeginInvoke will be called");

			IAsyncResult ar = del.BeginInvoke(null,null);
			Console.WriteLine("EndInvoke will be called");
			del.EndInvoke(ar);
			Console.WriteLine("Invocation done");

			Console.ReadLine();



		}	
	}
}

