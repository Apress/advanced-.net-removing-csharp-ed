using System;

namespace General {

	public interface IMySAO {
		void DoSomething();
	}

}
