using System;
using System.Runtime.Remoting;
using System.Threading;
using General;

namespace Server
{

	public class Broadcaster: MarshalByRefObject, IBroadcaster
	{

		public event General.MessageArrivedHandler MessageArrived;

		public void BroadcastMessage(string msg) {
			Console.WriteLine("Will broadcast message: {0}", msg);
			SafeInvokeEvent(msg);
		}

		private void SafeInvokeEvent(String msg) {
			// call the delegates manually to remove them if they aren't
			// active anymore.

			if (MessageArrived == null) {
				Console.WriteLine("No listeners");
			} else {
				Console.WriteLine("Number of Listeners: {0}",MessageArrived.GetInvocationList().Length);
				MessageArrivedHandler mah=null;

				foreach (Delegate del in MessageArrived.GetInvocationList()) {
					try {
						mah = (MessageArrivedHandler) del;
						mah(msg);
					} catch (Exception e) {
						Console.WriteLine("Exception occured, will remove Delegate");
						MessageArrived -= mah;
					}
				}
			}
		}

		public override object InitializeLifetimeService() {
			// this object has to live "forever"
			return null;
		}
	}


	class ServerStartup
	{
		static void Main(string[] args)
		{
			String filename = "server.exe.config";
			RemotingConfiguration.Configure(filename);

			Console.WriteLine ("Server started, press <return> to exit.");
			Console.ReadLine();
		}
	}
}
