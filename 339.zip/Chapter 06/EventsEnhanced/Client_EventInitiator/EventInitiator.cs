using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Activation;
using General;
using RemotingTools; // RemotingHelper


namespace Client
{
	class Client
	{

		static void Main(string[] args)
		{
			String filename = "EventInitiator.exe.config";
			RemotingConfiguration.Configure(filename);

			IBroadcaster bcast = 
				(IBroadcaster) RemotingHelper.GetObject(typeof(IBroadcaster));

			bcast.BroadcastMessage("Hello World! Events work fine now ... ");

			Console.WriteLine("Message sent");
			Console.ReadLine();
		}	
	}
}

