using System;
using System.Runtime.Remoting;
using General;
using RemotingTools; // RemotingHelper

namespace EventListener
{
	class EventListener
	{
		static void Main(string[] args)
		{
			String filename = "eventlistener.exe.config";
			RemotingConfiguration.Configure(filename);

			IBroadcaster bcaster = 
				(IBroadcaster) RemotingHelper.GetObject(typeof(IBroadcaster));

            // this one will be created in the client's context and a 
			// reference will be passed to the server
			BroadcastEventWrapper eventWrapper = 
				new BroadcastEventWrapper();
			
			// register the local handler with the "remote" handler
			eventWrapper.MessageArrivedLocally += 
				new MessageArrivedHandler(HandleMessage);

			Console.WriteLine("Registering event at server");
			bcaster.MessageArrived += 
				new MessageArrivedHandler(eventWrapper.LocallyHandleMessageArrived);

			Console.WriteLine("Event registered. Waiting for messages.");
			Console.ReadLine();
		}	

		public static void HandleMessage(String msg) {
			Console.WriteLine("Received: {0}",msg);
		}
	}


}

