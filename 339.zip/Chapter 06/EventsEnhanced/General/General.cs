using System;
using System.Runtime.Remoting.Messaging;

namespace General {

	public delegate void MessageArrivedHandler(String msg);

	public interface IBroadcaster {
		void BroadcastMessage(String msg);
		event MessageArrivedHandler MessageArrived;
	}


	public class BroadcastEventWrapper: MarshalByRefObject {
		public event MessageArrivedHandler MessageArrivedLocally;

		// don't use OneWay here!
		public void LocallyHandleMessageArrived (String msg) {
			// forward the message to the client
			MessageArrivedLocally(msg);
		}

		public override object InitializeLifetimeService() {
			// this object has to live "forever"
			return null;
		}
	}

}
