using System;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting;

namespace Server
{

	public class SomeCAO: ExtendedMBRObject
	{
		
		public SomeCAO() 
		{
			Console.WriteLine("SomeCAO.CTOR called");
		}

		public void doSomething() 
		{
			Console.WriteLine("SomeCAO.doSomething called");
		}
	}

	class ServerStartup
	{
		public static void Main(String[] args) 
		{
			RemotingConfiguration.Configure("server.exe.config");
			Console.WriteLine("Press <return> to exit");
			Console.ReadLine();
		}
	}
}
