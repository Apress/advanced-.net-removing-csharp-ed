using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Threading;
using Server; // from generated_meta.dll
using Sponsors; // from generated_meta.dll

namespace Client
{

	class EnsureKeepAlive 
	{
		private bool _keepServerAlive;
		private InstanceSponsor _sponsor;

		public EnsureKeepAlive(InstanceSponsor sponsor) 
		{
			_sponsor = sponsor;
			_keepServerAlive = true;
			Console.WriteLine("{0} KEEPALIVE: Starting thread()", DateTime.Now);
			Thread thrd = new Thread(new ThreadStart(this.KeepAliveThread));
			thrd.Start();
		}

		public void StopKeepAlive() 
		{
			_keepServerAlive= false;
		}

		public void KeepAliveThread() 
		{
			while (_keepServerAlive) 
			{
				Console.WriteLine("{0} KEEPALIVE: Will KeepAlive()", DateTime.Now);
				_sponsor.KeepAlive();
				Thread.Sleep(3000); 
			}
		}
	}

	class Client
	{
		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			SomeCAO cao = new SomeCAO();

			ILease le = (ILease) cao.GetLifetimeService();
			InstanceSponsor sponsor = new InstanceSponsor();

			// starting the keepalive thread
			EnsureKeepAlive keepalive = new EnsureKeepAlive(sponsor);

			// registering the sponsor
			le.Register((ISponsor) sponsor);

			try  
			{
				Console.WriteLine("{0} CLIENT: Calling doSomething()", DateTime.Now);
				cao.doSomething();
			} 
			catch (Exception e) 
			{
				Console.WriteLine(" --> EX: Timeout in first call\n{0}",e.Message);
			}
			Console.WriteLine("{0} CLIENT: Sleeping for 12 seconds", DateTime.Now);
			Thread.Sleep(12000);
			try 
			{
				Console.WriteLine("{0} CLIENT: Calling doSomething()", DateTime.Now);
				cao.doSomething();
			} 
			catch (Exception e) 
			{
				Console.WriteLine(" --> EX: Timeout in second call\n{0}",e.Message );
			}

			Console.WriteLine("{0} CLIENT: Telling sponsor to stop", DateTime.Now);
		
			// unregistering the sponsor
			((ILease) cao.GetLifetimeService()).Unregister((ISponsor) sponsor);
			// stopping the keepalive thread
			keepalive.StopKeepAlive();

			Console.WriteLine("Finished ... press <return> to exit");
			Console.ReadLine();
		}	
	}
}

