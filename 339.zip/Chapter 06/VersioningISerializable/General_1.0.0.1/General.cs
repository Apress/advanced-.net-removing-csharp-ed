using System;
using System.Runtime.Serialization;

namespace VersionedSerializableObjects
{
	[Serializable]
	public class Customer: ISerializable 
	{
		public String FirstName;
		public String LastName;
		public DateTime DateOfBirth;

		private const String VERSION = "1.0.0.1";// just for information

		public Customer (SerializationInfo info, StreamingContext context) {
			Console.WriteLine("Customer.ctor: Deserializing object [{0}]",VERSION);
			FirstName = info.GetString("FirstName");
			LastName = info.GetString("LastName");
			DateOfBirth = info.GetDateTime("DateOfBirth");
		}

		public Customer() 
		{
			Console.WriteLine("Customer.ctor: Object created [{0}]",VERSION);
		}

		public void dumpInfo() 
		{
			Console.WriteLine("Customer.dumpInfo: [{0}]",VERSION);
		}

		public void GetObjectData(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context) {
			info.AddValue("FirstName",FirstName);
			info.AddValue("LastName",LastName);
			info.AddValue("DateOfBirth",DateOfBirth);
		}

	}
}
