using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Threading;
using Server; // from generated_meta.dll
using VersionedSerializableObjects;

namespace Client
{

	class Client
	{
		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			SomeSAO sao = new SomeSAO();
			Customer cust = sao.getCustomer();
			cust.FirstName="John";
			cust.LastName="Doe";
			cust.DateOfBirth = new DateTime(1950,12,12);
			cust.dumpInfo();
			sao.doSomeThing(cust);
			Console.WriteLine("Finished ... press <return> to exit");
			Console.ReadLine();
		}	
	}
}

