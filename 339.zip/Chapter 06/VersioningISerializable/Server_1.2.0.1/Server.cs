using System;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting;
using VersionedSerializableObjects; 

namespace Server
{
	public class SomeSAO: MarshalByRefObject
	{
		public Customer getCustomer() 
		{
			Console.WriteLine("SomeSAO.getCustomer() called");
			Customer cust = new Customer();
			cust.dumpInfo();
			return cust;
		}

		public void doSomeThing(Customer cust) 
		{
			Console.WriteLine("SomeSAO.doSomething() called");
			Console.WriteLine("{0} {1}, {2}",cust.FirstName,
				cust.LastName, cust.Title);
			cust.dumpInfo();
		}
	}

	class ServerStartup
	{
		public static void Main(String[] args) 
		{
			RemotingConfiguration.Configure("server.exe.config");
			Console.WriteLine("Press <return> to exit");
			Console.ReadLine();
		}
	}

}
