using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Threading;
using Server; // from generated_meta.dll

namespace Client
{

	public class MySponsor: MarshalByRefObject, ISponsor 
	{

		public bool doRenewal = true;

		public TimeSpan Renewal(System.Runtime.Remoting.Lifetime.ILease lease) 
		{
			Console.WriteLine("{0} SPONSOR: Renewal() called", DateTime.Now);

			if (doRenewal) 
			{
				Console.WriteLine("{0} SPONSOR: Will renew (10 secs) ", DateTime.Now);
				return TimeSpan.FromSeconds(10);
			}
			else 
			{
				Console.WriteLine("{0} SPONSOR: Won't renew further", DateTime.Now);
				return TimeSpan.Zero;
			}
		}
	}
	
	class Client
	{
		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			SomeCAO cao = new SomeCAO();
			ILease le = (ILease) cao.GetLifetimeService();
			MySponsor sponsor = new MySponsor();
			le.Register(sponsor);

			try 
			{
				Console.WriteLine("{0} CLIENT: Calling doSomething()", DateTime.Now);
				cao.doSomething();
			} 
			catch (Exception e) 
			{
				Console.WriteLine(" --> EX: Timeout in first call\n{0}",e.Message);
			}
			Console.WriteLine("{0} CLIENT: Sleeping for 5 seconds", DateTime.Now);
			Thread.Sleep(5000);
			try 
			{
				Console.WriteLine("{0} CLIENT: Calling doSomething()", DateTime.Now);
				cao.doSomething();
			} 
			catch (Exception e) 
			{
				Console.WriteLine(" --> EX: Timeout in second call\n{0}",e.Message );
			}

			Console.WriteLine("{0} CLIENT: Telling sponsor to stop renewing", DateTime.Now);
			sponsor.doRenewal=false;

			Console.WriteLine("Finished ... press <return> to exit");
			Console.ReadLine();
		}	
	}
}

