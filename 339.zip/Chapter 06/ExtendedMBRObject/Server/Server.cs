using System;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting;

namespace Server
{
	public class DefaultLifeTimeSingleton: ExtendedMBRObject
	{
		
		public DefaultLifeTimeSingleton() 
		{
			Console.WriteLine("DefaultLifeTimeSingleton.CTOR called");
		}

		public void doSomething() 
		{
			Console.WriteLine("DefaultLifeTimeSingleton.doSomething called");
		}
	}

	public class LongerLivingSingleton: ExtendedMBRObject
	{
				
		public LongerLivingSingleton() 
		{
			Console.WriteLine("LongerLivingSingleton.CTOR called");
		}

		public void doSomething() 
		{
			Console.WriteLine("LongerLivingSingleton.doSomething called");
		}
	}

	public class InfinitelyLivingSingleton: ExtendedMBRObject
	{

		public InfinitelyLivingSingleton() 
		{
			Console.WriteLine("InfinitelyLivingSingleton.CTOR called");
		}

		public void doSomething() 
		{
			Console.WriteLine("InfinitelyLivingSingleton.doSomething called");
		}
	}

	class ServerStartup
	{
		public static void Main(String[] args) 
		{
			RemotingConfiguration.Configure("server.exe.config");
			Console.WriteLine("Press <return> to exit");
			Console.ReadLine();
		}
	}
}
