using System;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting;

namespace ServerApp
{

	class ServerStartup
	{
		public static void Main(String[] args) 
		{
			RemotingConfiguration.Configure("serverapp.exe.config");
			Console.WriteLine("Press <return> to exit");
			Console.ReadLine();
		}
	}
}
