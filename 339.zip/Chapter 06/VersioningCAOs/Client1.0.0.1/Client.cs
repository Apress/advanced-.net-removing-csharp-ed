using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Threading;
using Server; // from generated_meta.dll

namespace Client
{

	class Client
	{
		static void Main(string[] args)
		{
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			SomeCAO cao = new SomeCAO();
			cao.doSomething();

			Console.WriteLine("Finished ... press <return> to exit");
			Console.ReadLine();
		}	
	}
}

