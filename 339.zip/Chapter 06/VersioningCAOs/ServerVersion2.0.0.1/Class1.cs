using System;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting;

namespace Server
{

	public class SomeCAO: MarshalByRefObject
	{
		
		public SomeCAO() 
		{
			Console.WriteLine("Creating Version 2.0.0.1 CAO");
		}

		public void doSomething() 
		{
			Console.WriteLine("Calling Version 2.0.0.1 CAO");
		}
	}

}
