using System;

namespace VersionedSerializableObjects
{
	[Serializable]
	public class Customer 
	{
		public String FirstName;
		public String LastName;
		public DateTime DateOfBirth;

		private const String VERSION = "1.1.0.1";// just for information

		public Customer() 
		{
			Console.WriteLine("Customer.ctor: Object created [{0}]",VERSION);
		}

		public void dumpInfo() 
		{
			Console.WriteLine("Customer.dumpInfo: [{0}]",VERSION);
		}
	}
}
