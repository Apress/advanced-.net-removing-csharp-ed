using System;
using System.Collections;
using System.Runtime.Remoting;
using Server;

namespace Client {
	class Client {
		delegate void DoSomethingDelegate ();

		static void Main(string[] args) {
			String filename = "client.exe.config";
			RemotingConfiguration.Configure(filename);

			SomeSAO sao = new SomeSAO();
			

			// calling it synchronously to prove that 
			// everything's allright 

			Console.WriteLine("Will call synchronously");
			sao.DoSomething();
			Console.WriteLine("Synchronous call is ok");
			
			DoSomethingDelegate del = new DoSomethingDelegate(sao.DoSomething);
			
			try {
				Console.WriteLine("BeginInvoke will be called");
				IAsyncResult ar = del.BeginInvoke(null,null);

				Console.WriteLine("EndInvoke will be called");
				del.EndInvoke(ar);

				Console.WriteLine("Invocation done");
			} catch (Exception e) {
				Console.WriteLine("EXCEPTION \n{0}",e.Message);
			}

			Console.ReadLine();
		}	
	}
}

