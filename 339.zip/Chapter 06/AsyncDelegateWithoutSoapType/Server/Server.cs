using System;
using System.Runtime.Remoting;
using System.Threading;

namespace Server
{

	public class SomeSAO: MarshalByRefObject {
		public void DoSomething() {
			// simulating a long-running query
			Thread.Sleep(2000);
		}
	}

	class ServerStartup
	{
		static void Main(string[] args)
		{
			String filename = "server.exe.config";
			RemotingConfiguration.Configure(filename);

			Console.WriteLine ("Server started, press <return> to exit.");
			Console.ReadLine();
		}
	}
}
